/**
 *  @author 김민호
 */

const tab = document.querySelectorAll('.reco-left ul li')

tab.forEach(e =>{
    e.addEventListener('click', ()=>{
        data = 
    })

});
